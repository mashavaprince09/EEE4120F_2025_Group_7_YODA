from matplotlib.image import imread
import matplotlib.image as mpimg
import matplotlib.pylab as plt
import numpy as np
import sys

def load_from_image(path):
    rgb_image = imread("mage.jpg")
    red,green,blue = rgb_image[:,:,0], rgb_image[:,:,1], rgb_image[:,:,2] # Getting the image channels

    g = 1.04
    r_coeff, g_coeff, b_coeff = 0.2126, 0.7152, 0.0722
    return r_coeff*red**g + g_coeff*green**g + b_coeff*blue**g


def print_BW(gray_image, rgb_image):
    fig = plt.figure(1)
    img1,img2 = fig.add_subplot(121), fig.add_subplot(122)

    img1.imshow(rgb_image)
    img2.imshow(gray_image, cmap=plt.cm.get_cmap("gray"))

    fig.show()
    plt.show()


def save_hex(input, output):
    # Save as .hex textfile
    r,c = input.shape[0],input.shape[1]
    with open(f'{output}', 'w') as f:
        for i in range(r):
            for j in range(c):
                if i==r-1 and j==c-1:
                    f.write(f"{input[i,j]:x}")
                else:
                    f.write(f"{input[i,j]:x}\n")





